#!/usr/bin/perl -w
# description: (see showUsage at end)

use strict;

my $myName = $0;
$myName =~ s|^.*/([^/]+)$|$1|; # get basename of current program

my $numArgs = 1;  # number of required arguments
if($#ARGV != $numArgs ) { 
    $numArgs++;
# if there aren't the right number of arguments on the command line
    warn "$myName: wrong number of arguments on command line, 
There should be $numArgs.\n";
    &showUsage;
}

# main

my ($cmd, $team, $dataFile, $fileType, $sentCnt, $recall, $precision, $Fscore);
my ($partExact, $labelDep, $withNER, $frameOnly);

my $infile = $ARGV[0];  #typically one input file
open(INFILE, $infile) || die
    "$myName: can't open input file \"$infile\"; dying.\n";
my (@lines) = <INFILE>;
close(INFILE);

my $outfile= $ARGV[1];
open (OUTFILE, ">$outfile") || die
    "$myName: can't open output file \"$outfile\"; dying.\n";


my ($line, $outLine) = "Dummy";		    
$cmd = $team = $dataFile = $fileType = $sentCnt = $recall = $precision = $Fscore = "dummy";
$partExact = $labelDep = $withNER = $frameOnly = "Dummy";

for $line(@lines) { # main loop
  if ($line =~ /^Command:\s+fnSemScore(.*)$/) {
    $cmd = "$1";
# set more perspicacious variables

    # require exact frame matches, or give partial credit for
    # assigning to a "closey related" frame?
    $partExact = ($cmd =~ /-e/ ? "E" : "P");  

    # compare labels only, or sem. dependency structures?
    $labelDep = ($cmd =~ /-l/ ? "L" : "D");

    # include NER output in comparisons? 
    $withNER = ($cmd =~ /-n/ ? "N" : "Y");

    # check only for frames, or for FEs, too?
    $frameOnly = ($cmd =~ /-t/ ? "Y" : "N");

  }
  elsif ($line =~ /^Input file:\s+(.*)\/([ANCTI]+_[A-z]+)((_sem)?.xml)\s*$/) {
    $team = $1; $dataFile = $2; $fileType = $3;
  }
  elsif ($line =~ /^(\d+)\s+Sentences Scored: Recall=([0-9.]+).*Precision=([0-9.]+).*Fscore=([0-9.]+)/){
    $sentCnt = $1; $recall=$2; $precision=$3; $Fscore=$4;
    &outputLine;
    $cmd = $team = $dataFile = $fileType = $sentCnt = $recall = $precision = $Fscore = "dummy";
    $partExact = $labelDep = $withNER = $frameOnly = "Dummy";
  }
  else {
    warn "$myName: unrecognized line; skipping:\n$line";
  }
} # end main loop

sub outputLine { # use all global vars; too much to pass...
  $outLine = join "\t", $dataFile, $team, $cmd, $partExact, $labelDep, $withNER, $frameOnly, $sentCnt, $recall, $precision, $Fscore ;
  print OUTFILE "$outLine\n";
  
}

sub showUsage {
	die 
"\nUsage: $myName <infile> <outfile>

Reads output from fnSemScore, converts to tabbed format, ready to read
into a spreadsheet. In the process tried to convert the command-line
paramters into clearer values.
\n"; 
}

